        (function(){
                navAnim(".waypoint");   
                mobile_menu('.z-nav__list');
                cart(".cart");
                sequenceExp('.sequence');
                galleryPopup(".gallery-wrapper");
                count(".comming");
                customTabs('.tabs-custom');
                smoothScrollInit();
                initBlueberrySlider('.blueberry');
                
                
                //counters

                countDownHour("Jan 20, 2015", "Feb 20, 2015", "discount-1");
                countDownHour("Jan 20, 2015", "Feb 10, 2015", "discount-2");
                countDownHour("Jan 20, 2015", "Feb 16, 2015", "discount-3"); 

                countDownHour("Jan 20, 2015", "Feb 20, 2015", "timer-1");
                countDownHour("Jan 20, 2015", "Feb 10, 2015", "timer-2");
                countDownHour("Jan 20, 2015", "Feb 17, 2015", "timer-3");
                countDownHour("Jan 20, 2015", "Feb 30, 2015", "timer-4");  
	})();